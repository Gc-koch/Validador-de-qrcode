#!/usr/bin/env python3
"""
Script para testar o backend localmente antes do deploy
"""

import sys
import subprocess
import os

def check_python_version():
    """Verifica se a versão do Python é adequada"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ Python 3.8+ é necessário")
        print(f"   Versão atual: {version.major}.{version.minor}")
        return False
    print(f"✅ Python {version.major}.{version.minor} detectado")
    return True

def install_dependencies():
    """Instala as dependências necessárias"""
    print("\n📦 Instalando dependências...")
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r", 
            "api/requirements.txt", "--quiet"
        ])
        print("✅ Dependências instaladas com sucesso")
        return True
    except subprocess.CalledProcessError:
        print("❌ Erro ao instalar dependências")
        return False

def test_imports():
    """Testa se as bibliotecas necessárias estão disponíveis"""
    print("\n🔍 Testando importações...")
    try:
        import flask
        import flask_cors
        import requests
        print("✅ Todas as bibliotecas importadas com sucesso")
        return True
    except ImportError as e:
        print(f"❌ Erro ao importar: {e}")
        return False

def start_server():
    """Inicia o servidor Flask"""
    print("\n🚀 Iniciando servidor Flask...")
    print("   URL: http://localhost:5000")
    print("   Pressione Ctrl+C para parar\n")
    print("-" * 50)
    
    try:
        # Muda para o diretório da API
        os.chdir('api')
        
        # Inicia o servidor
        subprocess.run([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\n\n✅ Servidor parado")
    except Exception as e:
        print(f"\n❌ Erro ao iniciar servidor: {e}")

def main():
    print("=" * 50)
    print("🧪 TESTE DO BACKEND - QR Code Validator")
    print("=" * 50)
    
    if not check_python_version():
        sys.exit(1)
    
    if not install_dependencies():
        sys.exit(1)
    
    if not test_imports():
        print("\n💡 Tente reinstalar as dependências:")
        print("   pip install -r api/requirements.txt")
        sys.exit(1)
    
    print("\n" + "=" * 50)
    print("✅ Tudo pronto!")
    print("=" * 50)
    
    start_server()

if __name__ == "__main__":
    main()
